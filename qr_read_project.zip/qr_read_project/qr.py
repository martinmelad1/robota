import cv2 as cv 

vid = "qr_Read\Vid\QR_vid.mp4"
img = "qr_Read\Img\QR_img.png"
cam = 0

def QR_Detector(img):
    detector = cv.QRCodeDetector()
    data, isDetected, straight_qrcode = detector.detectAndDecode(img)
    #print("isDetected: ", isDetected)
    if isDetected is not None:
        if data:
            return data
    
def vid_framing(Vid_path):
    data = None
    cap = cv.VideoCapture(Vid_path)
    while True:
        isTrue, frame = cap.read()
        if isTrue:
            data = QR_Detector(frame)
            #cv.imshow("Frame", frame)
            if data is not None:
                print("QR code data found in frame")
                break
            if cv.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            break

    cap.release()
    cv.destroyAllWindows()
    return data

def img_framing(img_path):
    data = None
    img = cv.imread(img_path)
    data = QR_Detector(img)
    return data

def cam_framing(Cam_num):
    data = None
    cap = cv.VideoCapture(Cam_num)
    while True:
        isTrue, frame = cap.read()
        if isTrue:
            cv.imshow('frame', frame)
            data = QR_Detector(frame)
            if data is not None:
                print("QR code data found in frame")
                break
            if cv.waitKey(1) & 0xFF == ord('q'):
                break
        else:
            break

    cap.release()
    cv.destroyAllWindows()
    return data

print("data: ", vid_framing(vid))
print("data: ", img_framing(img))
print("data: ", cam_framing(cam))